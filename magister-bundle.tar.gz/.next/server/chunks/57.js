"use strict";exports.id=57,exports.ids=[57],exports.modules={25057:(a,b,c)=>{c.d(b,{ZA:()=>P,NQ:()=>J,YC:()=>y,$k:()=>v,ye:()=>V,Sw:()=>w,Gs:()=>s,lC:()=>C,YE:()=>M,kw:()=>T,XL:()=>q,fy:()=>z,SR:()=>u,XC:()=>G,af:()=>N,u0:()=>S,Nm:()=>D,yk:()=>B,NS:()=>H,td:()=>O,qQ:()=>I,O5:()=>A,Nr:()=>F,tX:()=>L,TZ:()=>t,Oj:()=>K,jE:()=>W,au:()=>Q,t:()=>x});var d=c(29021),e=c.n(d),f=c(33873),g=c.n(f),h=c(55511),i=c.n(h),j=c(87082),k=c.n(j),l=c(79868);let m=["Iqtisodiyot","Aniq fanlar","Maktabgacha va boshlang'ich ta'lim","Tarix","Tillar","Tabiiy fanlat va yibbiyot","San'at va sport"],n=globalThis;function o(){if(!n.magisterDb){let a=g().join(process.cwd(),"data");e().mkdirSync(a,{recursive:!0});let b=new l.DatabaseSync(g().join(a,"magister.sqlite"));b.exec("PRAGMA foreign_keys = ON"),n.magisterDb=b}return n.magisterDb}let p=null;function q(){return p||(p=Promise.resolve().then(()=>(function(){let a=o();a.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id text PRIMARY KEY,
      full_name text NOT NULL,
      email text UNIQUE NOT NULL,
      password_hash text NOT NULL,
      role text NOT NULL CHECK (role IN ('ADMIN', 'MAGISTR')),
      phone text,
      faculty text,
      department text,
      specialty text,
      course integer,
      funding text,
      created_at text NOT NULL
    );

    CREATE TABLE IF NOT EXISTS documents (
      id text PRIMARY KEY,
      owner_id text NOT NULL REFERENCES users(id),
      type text NOT NULL,
      title text NOT NULL,
      body text NOT NULL,
      status text NOT NULL CHECK (status IN ('DRAFT','SUBMITTED','IN_REVIEW','APPROVED','REVISION','REJECTED')),
      created_at text NOT NULL,
      updated_at text NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id text PRIMARY KEY,
      document_id text NOT NULL REFERENCES documents(id),
      admin_id text NOT NULL REFERENCES users(id),
      action text NOT NULL CHECK (action IN ('APPROVE','REJECT','REVISION')),
      comment text NOT NULL CHECK (length(trim(comment)) >= 3),
      created_at text NOT NULL
    );

    CREATE TABLE IF NOT EXISTS submission_rounds (
      id text PRIMARY KEY,
      document_id text NOT NULL REFERENCES documents(id),
      version integer NOT NULL,
      note text NOT NULL,
      created_at text NOT NULL
    );

    CREATE TABLE IF NOT EXISTS submission_files (
      id text PRIMARY KEY,
      round_id text NOT NULL REFERENCES submission_rounds(id),
      label text NOT NULL,
      stored_name text NOT NULL,
      original_name text NOT NULL,
      mime text,
      size integer NOT NULL,
      created_at text NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_events (
      id text PRIMARY KEY,
      created_at text NOT NULL,
      user_id text,
      user_name text,
      user_email text,
      role text,
      action text NOT NULL,
      path text,
      ip text,
      user_agent text,
      target text,
      ok integer NOT NULL,
      detail text
    );
    CREATE INDEX IF NOT EXISTS audit_events_created ON audit_events(created_at);

    CREATE TABLE IF NOT EXISTS faculties (
      id text PRIMARY KEY,
      name text NOT NULL UNIQUE,
      created_at text NOT NULL
    );
    CREATE TABLE IF NOT EXISTS departments (
      id text PRIMARY KEY,
      faculty_id text NOT NULL REFERENCES faculties(id),
      name text NOT NULL,
      created_at text NOT NULL,
      UNIQUE (faculty_id, name)
    );
    CREATE TABLE IF NOT EXISTS specialties (
      id text PRIMARY KEY,
      department_id text NOT NULL REFERENCES departments(id),
      name text NOT NULL,
      created_at text NOT NULL,
      UNIQUE (department_id, name)
    );
  `);let b=new Set(a.prepare("PRAGMA table_info(users)").all().map(a=>a.name));b.has("account_status")||a.exec("ALTER TABLE users ADD COLUMN account_status text NOT NULL DEFAULT 'ACTIVE' CHECK (account_status IN ('PENDING', 'ACTIVE', 'REJECTED'))"),b.has("status_note")||a.exec("ALTER TABLE users ADD COLUMN status_note text"),new Set(a.prepare("PRAGMA table_info(reviews)").all().map(a=>a.name)).has("governance_ref")||a.exec("ALTER TABLE reviews ADD COLUMN governance_ref text");let c=new Date().toISOString(),d=k().hashSync("Admin123!",10),e=k().hashSync("Magistr123!",10),f=a.prepare(`
    INSERT INTO users (id, full_name, email, password_hash, role, phone, faculty, department, specialty, course, funding, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT (email) DO NOTHING
  `);if(f.run("11111111-1111-4111-8111-111111111111","Nodira Karimova","admin@magister.local",d,"ADMIN","+998901112233","Magistratura bo‘limi",null,null,null,null,c),f.run("22222222-2222-4222-8222-222222222222","Aliyev Akmal","aliyev@magister.local",e,"MAGISTR","+998907770011","Iqtisodiyot","Menejment","Menejment",1,"Grant",c),f.run("33333333-3333-4333-8333-333333333333","Karimova Dilnoza","karimova@magister.local",e,"MAGISTR","+998907770022","Filologiya","Adabiyot","Adabiyotshunoslik",2,"Kontrakt",c),0===a.prepare("SELECT count(*) AS count FROM documents").get().count){let b=a.prepare(`
    INSERT INTO documents (id, owner_id, type, title, body, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);b.run("aaaaaaa1-aaaa-4aaa-8aaa-aaaaaaaaaaa1","22222222-2222-4222-8222-222222222222","PLAN","1-kurs kalendar ish rejasi","O‘quv-metodik ishlar: sentabr–oktabr fanlar bo‘yicha konspekt.\nIlmiy-tadqiqot: mavzu bo‘yicha 15 ta manba kartotekasi.\nIlmiy-pedagogik: 2 ta seminar.\nPedagogik amaliyot: noyabr, 3-maktab.\nDissertatsiya: kirish qoralamasi dekabrda.","SUBMITTED",c,c),b.run("aaaaaaa2-aaaa-4aaa-8aaa-aaaaaaaaaaa2","22222222-2222-4222-8222-222222222222","REPORT","Sentabr oyi hisoboti","1-band bajarildi: 4 ta manba o‘qildi.\n2-band natijasi hali yozilmagan.\nSeminar 12-sentabrda o‘tildi.","REVISION",c,c),b.run("aaaaaaa3-aaaa-4aaa-8aaa-aaaaaaaaaaa3","22222222-2222-4222-8222-222222222222","PRACTICE","Pedagogik amaliyot kundaligi","Amaliyot joyi hali tasdiqlanmagan. Kundalik keyinroq to‘ldiriladi.","DRAFT",c,c),b.run("aaaaaaa4-aaaa-4aaa-8aaa-aaaaaaaaaaa4","33333333-3333-4333-8333-333333333333","DISSERTATION","Mavzu taklifi","Mavzu: Zamonaviy o‘zbek romanida shahar obrazi.\nDolzarblik: shahar makoni adabiy qahramonning tanloviga ta’sir qiladi.\nMaqsad: 1991-yildan keyingi romanlarda shahar obrazini tahlil qilish.","SUBMITTED",c,c),b.run("aaaaaaa5-aaaa-4aaa-8aaa-aaaaaaaaaaa5","33333333-3333-4333-8333-333333333333","SOCIAL","Xalqaro konferensiya ishtiroki","Toshkentdagi filologiya anjumanida tezis bilan qatnashdim. Sertifikat ilova qilinadi.","APPROVED",c,c),b.run("aaaaaaa6-aaaa-4aaa-8aaa-aaaaaaaaaaa6","22222222-2222-4222-8222-222222222222","ARTICLE","Scopus: Raqamli iqtisodiyotda intellektual boshqaruv tizimlari","[ILMIY NASHR MA’LUMOTLARI]\nBaza: Scopus\nJurnal / To‘plam: International Journal of Information Management\nJild / Son / Bet: 2025-yil, Vol. 48, 112-124-betlar\nDOI / Havola: https://doi.org/10.1016/j.ijinfomgt.2025.102\nHammualliflar: dots. A. Karimov","APPROVED",c,c);let d=a.prepare(`
    INSERT INTO reviews (id, document_id, admin_id, action, comment, governance_ref, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);d.run("bbbbbbb1-bbbb-4bbb-8bbb-bbbbbbbbbbb1","aaaaaaa2-aaaa-4aaa-8aaa-aaaaaaaaaaa2","11111111-1111-4111-8111-111111111111","REVISION","Oylik hisobotda 2-band natijasi yozilmagan. Shu bandni to‘ldirib, qayta yuboring.",null,c),d.run("bbbbbbb2-bbbb-4bbb-8bbb-bbbbbbbbbbb2","aaaaaaa5-aaaa-4aaa-8aaa-aaaaaaaaaaa5","11111111-1111-4111-8111-111111111111","APPROVE","Konferensiya sertifikati qabul qilindi. Ijtimoiy faoliyat tasdiqlandi.","Kafedra bayonnomasi №1, 15.09.2025",c),d.run("bbbbbbb3-bbbb-4bbb-8bbb-bbbbbbbbbbb3","aaaaaaa6-aaaa-4aaa-8aaa-aaaaaaaaaaa6","11111111-1111-4111-8111-111111111111","APPROVE","Xalqaro Scopus bazasida indekslangan ilmiy maqola Nizom 36-son bo‘yicha to‘liq tasdiqlandi.","Kafedra bayonnomasi №3, 14.10.2025",c)}let g=a.prepare(`
    INSERT INTO users (id, full_name, email, password_hash, role, phone, faculty, department, specialty, course, funding, created_at)
    VALUES (?, ?, ?, ?, 'MAGISTR', ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT (email) DO NOTHING
  `);for(let a of[["44444444-4444-4444-8444-444444444444","Rahimov Jasur","rahimov@magister.local","+998901110001","Texnika","Energetika","Energetika",1,"Grant","2025-09-02T08:00:00.000Z"],["55555555-5555-4555-8555-555555555555","Saidova Madina","saidova@magister.local","+998901110002","Pedagogika","Pedagogika","Pedagogika",2,"Kontrakt","2025-09-02T08:10:00.000Z"],["66666666-6666-4666-8666-666666666666","Tursunov Bekzod","tursunov@magister.local","+998901110003","Yuridik","Yurisprudensiya","Yurisprudensiya",1,"Grant","2025-09-03T08:00:00.000Z"],["77777777-7777-4777-8777-777777777777","Eshonova Nilufar","eshonova@magister.local","+998901110004","Iqtisodiyot","Moliya","Moliya",2,"Grant","2025-09-03T08:20:00.000Z"]])g.run(a[0],a[1],a[2],e,a[3],a[4],a[5],a[6],a[7],a[8],a[9]);let h=a.prepare(`
    INSERT OR IGNORE INTO documents (id, owner_id, type, title, body, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);for(let a of[["ccccccc1-cccc-4ccc-8ccc-ccccccccccc1","44444444-4444-4444-8444-444444444444","PLAN","Energetika kalendar rejasi","O‘quv, laboratoriya va amaliyot bandlari semestr bo‘yicha yozilgan.","APPROVED","2025-10-04T09:00:00.000Z"],["ccccccc2-cccc-4ccc-8ccc-ccccccccccc2","44444444-4444-4444-8444-444444444444","REPORT","Oktabr oyi hisoboti","Laboratoriya ishi topshirildi. Maqola hali tayyor emas.","SUBMITTED","2025-11-02T11:20:00.000Z"],["ccccccc3-cccc-4ccc-8ccc-ccccccccccc3","55555555-5555-4555-8555-555555555555","DISSERTATION","Pedagogik texnologiya mavzusi","Mavzu: Boshlang‘ich sinfda baholash mezonlari.","IN_REVIEW","2025-11-12T14:00:00.000Z"],["ccccccc4-cccc-4ccc-8ccc-ccccccccccc4","55555555-5555-4555-8555-555555555555","SOCIAL","Ko‘ngillilar haftaligi","Sertifikat ilova qilinmagan.","REJECTED","2025-10-20T10:00:00.000Z"],["ccccccc5-cccc-4ccc-8ccc-ccccccccccc5","66666666-6666-4666-8666-666666666666","PRACTICE","Yuridik klinika kundaligi","Qoralama. Joy va rahbar hali yozilmagan.","DRAFT","2025-11-18T09:30:00.000Z"],["ccccccc6-cccc-4ccc-8ccc-ccccccccccc6","66666666-6666-4666-8666-666666666666","PLAN","1-kurs ish rejasi","Dissertatsiya bosqichi muddatsiz qoldirilgan.","REVISION","2025-10-28T16:10:00.000Z"],["ccccccc7-cccc-4ccc-8ccc-ccccccccccc7","77777777-7777-4777-8777-777777777777","REPORT","Sentabr moliyaviy hisobot","Uchta manba va seminar bayonnomasi ilova qilingan.","APPROVED","2025-10-08T12:00:00.000Z"],["ccccccc8-cccc-4ccc-8ccc-ccccccccccc8","77777777-7777-4777-8777-777777777777","DISSERTATION","Byudjet nazorati mavzusi","Mavzu taklifi va dolzarblik yozilgan.","SUBMITTED","2025-11-21T08:40:00.000Z"],["ccccccc9-cccc-4ccc-8ccc-ccccccccccc9","77777777-7777-4777-8777-777777777777","SOCIAL","Ilmiy to‘garak","Noyabr oyidagi to‘garak qatnashuvi, qoralama.","DRAFT","2025-11-22T08:40:00.000Z"],["ccccccca-cccc-4ccc-8ccc-ccccccccccc0","77777777-7777-4777-8777-777777777777","ARTICLE","Scopus: Moliya tizimida ekonometrik modellashtirish","[ILMIY NASHR MA’LUMOTLARI]\nBaza: Scopus\nJurnal / To‘plam: Finance Research Letters\nJild / Son / Bet: 2025-yil, Vol. 56, 210-218-betlar\nDOI / Havola: https://doi.org/10.1016/j.frl.2025.104\nHammualliflar: dots. B. Qodirov","APPROVED","2025-11-05T10:00:00.000Z"]])h.run(a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[6]);let j=a.prepare(`
    INSERT OR IGNORE INTO reviews (id, document_id, admin_id, action, comment, governance_ref, created_at)
    VALUES (?, ?, '11111111-1111-4111-8111-111111111111', ?, ?, ?, ?)
  `);j.run("ddddddd1-dddd-4ddd-8ddd-ddddddddddd1","ccccccc1-cccc-4ccc-8ccc-ccccccccccc1","APPROVE","Beshta bo‘lim muddati bilan yozilgan. Kalendar reja qabul qilindi.","Kafedra bayonnomasi №2, 02.10.2025","2025-10-04T09:30:00.000Z"),j.run("ddddddd2-dddd-4ddd-8ddd-ddddddddddd2","ccccccc4-cccc-4ccc-8ccc-ccccccccccc4","REJECT","Tasdiqlovchi sertifikat yo‘q. Hujjatni rad etaman.",null,"2025-10-20T10:20:00.000Z"),j.run("ddddddd3-dddd-4ddd-8ddd-ddddddddddd3","ccccccc6-cccc-4ccc-8ccc-ccccccccccc6","REVISION","Dissertatsiya bosqichiga aniq oy yozib, qayta yuboring.",null,"2025-10-28T16:40:00.000Z"),j.run("ddddddd4-dddd-4ddd-8ddd-ddddddddddd4","ccccccc7-cccc-4ccc-8ccc-ccccccccccc7","APPROVE","Manbalar va seminar bayonnomasi yetarli. Hisobot qabul qilindi.","Kafedra bayonnomasi №3, 08.10.2025","2025-10-08T12:30:00.000Z"),j.run("ddddddd5-dddd-4ddd-8ddd-ddddddddddd5","ccccccca-cccc-4ccc-8ccc-ccccccccccc0","APPROVE","Xalqaro Scopus bazasida indekslangan ilmiy maqola to‘liq tasdiqlandi.","Kafedra bayonnomasi №4, 05.11.2025","2025-11-05T10:30:00.000Z"),function(a){let b=new Date().toISOString(),c=a.prepare("INSERT OR IGNORE INTO faculties (id, name, created_at) VALUES (?, ?, ?)"),d=a.prepare("SELECT id FROM faculties WHERE name = ?"),e=a.prepare("INSERT OR IGNORE INTO departments (id, faculty_id, name, created_at) VALUES (?, ?, ?, ?)"),f=a.prepare("SELECT id FROM departments WHERE faculty_id = ? AND name = ?"),g=a.prepare("INSERT OR IGNORE INTO specialties (id, department_id, name, created_at) VALUES (?, ?, ?, ?)");for(let a of m)c.run(i().randomUUID(),a,b);for(let h of a.prepare("SELECT faculty, department, specialty FROM users WHERE role = 'MAGISTR'").all()){let a=h.faculty?.trim()??"";if(a.length<2)continue;c.run(i().randomUUID(),a,b);let j=d.get(a).id,k=h.department?.trim()??"";if(k.length<2)continue;e.run(i().randomUUID(),j,k,b);let l=f.get(j,k).id,m=h.specialty?.trim()??"";m.length<2||g.run(i().randomUUID(),l,m,b)}}(a)})()).catch(a=>{throw p=null,a})),p}let r="id, full_name, email, role, phone, faculty, department, specialty, course, funding, account_status, status_note";async function s(a){return await q(),o().prepare(`SELECT ${r}, password_hash FROM users WHERE email = ?`).get(a.trim().toLowerCase())??null}async function t(a){await q();let b=a.email.trim().toLowerCase();if(await s(b))return{error:"Bu email allaqachon ro‘yxatdan o‘tgan."};let c=i().randomUUID();return o().prepare(`INSERT INTO users (id, full_name, email, password_hash, role, phone, faculty, department, specialty, course, funding, account_status, created_at)
       VALUES (?, ?, ?, ?, 'MAGISTR', ?, ?, ?, ?, ?, ?, 'PENDING', ?)`).run(c,a.fullName.trim(),b,k().hashSync(a.password,10),a.phone.trim(),a.faculty.trim(),a.department.trim(),a.specialty.trim(),a.course,a.funding,new Date().toISOString()),{id:c,role:"MAGISTR",account_status:"PENDING"}}async function u(a){return await q(),o().prepare(`SELECT ${r}, created_at FROM users WHERE role = 'MAGISTR' AND account_status = ? ORDER BY created_at DESC`).all(a)}async function v(){await q();let a=o().prepare("SELECT count(*) AS n FROM users WHERE role = 'MAGISTR' AND account_status = 'PENDING'").get();return Number(a?.n??0)}async function w(a){await q();let b=a.note.trim();if(b.length<3)return{error:"Komment kamida 3 ta belgidan iborat bo‘lsin."};let c=o().prepare("SELECT role, account_status FROM users WHERE id = ?").get(a.id);return c&&"MAGISTR"===c.role?"APPROVE"===a.action?"ACTIVE"===c.account_status?{error:"Hisob allaqachon ochiq."}:(o().prepare("UPDATE users SET account_status = 'ACTIVE', status_note = ? WHERE id = ?").run(b,a.id),{ok:!0}):"PENDING"!==c.account_status?{error:"Bu so‘rovni rad etib bo‘lmaydi."}:(o().prepare("UPDATE users SET account_status = 'REJECTED', status_note = ? WHERE id = ?").run(b,a.id),{ok:!0}):{error:"So‘rov topilmadi."}}async function x(a,b){await q();let c=b.email.trim().toLowerCase();return o().prepare("SELECT id FROM users WHERE email = ? AND id <> ?").get(c,a.id)?{error:"Bu email allaqachon ishlatilgan."}:("ADMIN"===a.role?o().prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?").run(b.fullName.trim(),c,b.phone.trim()||null,a.id):o().prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, faculty = ?, department = ?, specialty = ?, course = ?, funding = ? WHERE id = ? AND account_status = 'ACTIVE'").run(b.fullName.trim(),c,b.phone.trim(),b.faculty?.trim()??"",b.department?.trim()??"",b.specialty?.trim()??"",b.course??null,b.funding??"",a.id),{ok:!0})}async function y(a,b,c){await q();let d=o().prepare("SELECT password_hash FROM users WHERE id = ?").get(a);return d&&k().compareSync(b,d.password_hash)?(o().prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(k().hashSync(c,10),a),{ok:!0}):{error:"Joriy parol noto‘g‘ri."}}async function z(a){await q();let b=o(),c=new Date().toISOString();if("PAGE_VIEW"===a.action){let c=new Date(Date.now()-9e4).toISOString();if(b.prepare("SELECT id FROM audit_events WHERE action = 'PAGE_VIEW' AND ifnull(path, '') = ? AND ifnull(user_id, '') = ? AND ifnull(ip, '') = ? AND created_at >= ?").get(a.path??"",a.userId??"",a.ip,c))return}b.prepare(`INSERT INTO audit_events (id, created_at, user_id, user_name, user_email, role, action, path, ip, user_agent, target, ok, detail)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(i().randomUUID(),c,a.userId,a.userName,a.userEmail,a.role,a.action,a.path,a.ip,a.userAgent.slice(0,180),a.target,+!!a.ok,a.detail)}async function A(a){await q();let b=["created_at >= ?","created_at < ?"],c=[a.from,a.to];if(a.q){b.push("(ifnull(user_name, '') LIKE ? OR ifnull(user_email, '') LIKE ? OR ifnull(detail, '') LIKE ?)");let d=`%${a.q}%`;c.push(d,d,d)}return("ADMIN"===a.role||"MAGISTR"===a.role)&&(b.push("role = ?"),c.push(a.role)),a.action&&(b.push("action = ?"),c.push(a.action)),a.ip&&(b.push("ifnull(ip, '') LIKE ?"),c.push(`%${a.ip}%`)),a.path&&(b.push("ifnull(path, '') LIKE ?"),c.push(`%${a.path}%`)),("1"===a.ok||"0"===a.ok)&&(b.push("ok = ?"),c.push(Number(a.ok))),o().prepare(`SELECT * FROM audit_events WHERE ${b.join(" AND ")} ORDER BY created_at DESC LIMIT 200`).all(...c)}async function B(){await q();let a=o(),b=a.prepare(`SELECT d.id, d.type, d.status, d.title, d.created_at, u.full_name AS owner_name, u.faculty, u.specialty, u.funding, u.course
       FROM documents d JOIN users u ON u.id = d.owner_id`).all();return{docs:b,reviews:a.prepare(`SELECT r.created_at, r.action, r.comment, a.full_name AS admin_name, d.title, d.created_at AS doc_created,
              u.full_name AS owner_name, u.faculty, u.specialty
       FROM reviews r
       JOIN users a ON a.id = r.admin_id
       JOIN documents d ON d.id = r.document_id
       JOIN users u ON u.id = d.owner_id`).all(),people:a.prepare("SELECT full_name, faculty, specialty, course, funding, account_status, created_at FROM users WHERE role = 'MAGISTR'").all()}}async function C(a){return await q(),o().prepare(`SELECT ${r} FROM users WHERE id = ?`).get(a)??null}async function D(){return await q(),o().prepare(`SELECT ${r} FROM users WHERE role = 'MAGISTR' ORDER BY full_name`).all()}let E=`
  SELECT d.id, d.owner_id, d.type, d.title, d.body, d.status, d.created_at, d.updated_at,
         u.full_name AS owner_name, u.faculty, u.department, u.course, u.funding,
         (SELECT comment FROM reviews r WHERE r.document_id = d.id ORDER BY r.created_at DESC LIMIT 1) AS last_comment,
         (SELECT action FROM reviews r WHERE r.document_id = d.id ORDER BY r.created_at DESC LIMIT 1) AS last_action
  FROM documents d
  JOIN users u ON u.id = d.owner_id
`;async function F(a={}){await q();let b=[],c=[];if(a.ownerId&&(b.push("d.owner_id = ?"),c.push(a.ownerId)),a.status&&(b.push("d.status = ?"),c.push(a.status)),a.type&&(b.push("d.type = ?"),c.push(a.type)),a.faculty&&(b.push("u.faculty = ?"),c.push(a.faculty)),a.course&&(b.push("u.course = ?"),c.push(Number(a.course))),a.funding&&(b.push("u.funding = ?"),c.push(a.funding)),a.q){b.push("(d.title LIKE ? OR d.body LIKE ? OR u.full_name LIKE ? OR ifnull(u.specialty, '') LIKE ?)");let d=`%${a.q}%`;c.push(d,d,d,d)}let d=`${E} ${b.length?`WHERE ${b.join(" AND ")}`:""} ORDER BY d.updated_at DESC`;return o().prepare(d).all(...c)}async function G(){return await q(),o().prepare("SELECT name AS faculty FROM faculties ORDER BY name").all()}async function H(){await q();let a=o(),b=a.prepare("SELECT id, name FROM faculties ORDER BY name").all(),c=a.prepare("SELECT id, faculty_id, name FROM departments ORDER BY name").all(),d=a.prepare("SELECT id, department_id, name FROM specialties ORDER BY name").all();return b.map(a=>({id:a.id,name:a.name,departments:c.filter(b=>b.faculty_id===a.id).map(a=>({id:a.id,name:a.name,specialties:d.filter(b=>b.department_id===a.id).map(a=>({id:a.id,name:a.name}))}))}))}async function I(a,b,c){return await q(),!!o().prepare(`SELECT s.id FROM specialties s
       JOIN departments d ON d.id = s.department_id
       JOIN faculties f ON f.id = d.faculty_id
       WHERE f.name = ? AND d.name = ? AND s.name = ?`).get(a,b,c)}async function J(a){await q();let b=a.name.trim();if(b.length<2)return{error:"Nom kamida 2 ta belgidan iborat bo‘lsin."};let c=o(),d=new Date().toISOString(),e=i().randomUUID();try{if("faculty"===a.kind)c.prepare("INSERT INTO faculties (id, name, created_at) VALUES (?, ?, ?)").run(e,b,d);else if("department"===a.kind){if(!a.parentId)return{error:"Avval fakultetni tanlang."};c.prepare("INSERT INTO departments (id, faculty_id, name, created_at) VALUES (?, ?, ?, ?)").run(e,a.parentId,b,d)}else{if(!a.parentId)return{error:"Avval kafedrani tanlang."};c.prepare("INSERT INTO specialties (id, department_id, name, created_at) VALUES (?, ?, ?, ?)").run(e,a.parentId,b,d)}}catch{return{error:"Bu nom allaqachon bor."}}return{id:e}}async function K(a){await q();let b=o();if("faculty"===a.kind){let c=b.prepare("SELECT name FROM faculties WHERE id = ?").get(a.id);if(!c)return{error:"Fakultet topilmadi."};let d=b.prepare("SELECT count(*) AS count FROM users WHERE faculty = ?").get(c.name),e=b.prepare("SELECT count(*) AS count FROM departments WHERE faculty_id = ?").get(a.id);if(d.count||e.count)return{error:"Avval kafedralar va shu fakultetdagi talabalar bo‘lmasligi kerak."};b.prepare("DELETE FROM faculties WHERE id = ?").run(a.id)}else if("department"===a.kind){let c=b.prepare("SELECT d.name, f.name AS faculty FROM departments d JOIN faculties f ON f.id = d.faculty_id WHERE d.id = ?").get(a.id);if(!c)return{error:"Kafedra topilmadi."};let d=b.prepare("SELECT count(*) AS count FROM users WHERE faculty = ? AND department = ?").get(c.faculty,c.name),e=b.prepare("SELECT count(*) AS count FROM specialties WHERE department_id = ?").get(a.id);if(d.count||e.count)return{error:"Avval mutaxassisliklar va shu kafedradagi talabalar bo‘lmasligi kerak."};b.prepare("DELETE FROM departments WHERE id = ?").run(a.id)}else{let c=b.prepare(`SELECT s.name, d.name AS department, f.name AS faculty
       FROM specialties s JOIN departments d ON d.id = s.department_id JOIN faculties f ON f.id = d.faculty_id
       WHERE s.id = ?`).get(a.id);if(!c)return{error:"Mutaxassislik topilmadi."};if(b.prepare("SELECT count(*) AS count FROM users WHERE faculty = ? AND department = ? AND specialty = ?").get(c.faculty,c.department,c.name).count)return{error:"Bu mutaxassislikda talaba bor. O‘chirib bo‘lmaydi."};b.prepare("DELETE FROM specialties WHERE id = ?").run(a.id)}return{ok:!0}}async function L(a={}){await q();let b=["u.role = 'MAGISTR'","u.account_status = 'ACTIVE'"],c=[];if(a.faculty&&(b.push("u.faculty = ?"),c.push(a.faculty)),a.course&&(b.push("u.course = ?"),c.push(Number(a.course))),a.funding&&(b.push("u.funding = ?"),c.push(a.funding)),a.q){b.push("(u.full_name LIKE ? OR u.email LIKE ? OR ifnull(u.specialty, '') LIKE ? OR ifnull(u.department, '') LIKE ?)");let d=`%${a.q}%`;c.push(d,d,d,d)}return o().prepare(`
      SELECT ${r.split(", ").map(a=>`u.${a}`).join(", ")},
        (SELECT count(*) FROM documents d WHERE d.owner_id = u.id) AS docs,
        (SELECT count(*) FROM documents d WHERE d.owner_id = u.id AND d.status IN ('SUBMITTED','IN_REVIEW')) AS awaiting,
        (SELECT count(*) FROM documents d WHERE d.owner_id = u.id AND d.status = 'APPROVED') AS approved,
        (SELECT count(*) FROM documents d WHERE d.owner_id = u.id AND d.status = 'REVISION') AS revision
      FROM users u
      WHERE ${b.join(" AND ")}
      ORDER BY u.faculty, u.full_name
    `).all(...c)}async function M(a){return await q(),o().prepare(`${E} WHERE d.id = ?`).get(a)??null}async function N(a){return await q(),o().prepare(`
      SELECT r.id, r.document_id, r.admin_id, a.full_name AS admin_name, r.action, r.comment, r.governance_ref, r.created_at
      FROM reviews r
      JOIN users a ON a.id = r.admin_id
      WHERE r.document_id = ?
      ORDER BY r.created_at ASC
    `).all(a)}async function O(a){await q(),o().prepare("UPDATE documents SET status = 'IN_REVIEW', updated_at = ? WHERE id = ? AND status = 'SUBMITTED'").run(new Date().toISOString(),a)}class P extends Error{}async function Q(a){await q();let b=a.comment.trim(),c=a.governanceRef?.trim()||null;if(b.length<3)throw new P("Qaror faqat komment bilan saqlanadi.");if(!["APPROVE","REJECT","REVISION"].includes(a.action))throw new P("Noto‘g‘ri qaror.");let d="APPROVE"===a.action?"APPROVED":"REJECT"===a.action?"REJECTED":"REVISION",e=o();e.exec("BEGIN");try{let f=e.prepare("SELECT status FROM documents WHERE id = ?").get(a.documentId);if(!f)throw new P("Hujjat topilmadi.");if("SUBMITTED"!==f.status&&"IN_REVIEW"!==f.status)throw new P("Bu hujjat qaror kutmayapti.");e.prepare("INSERT INTO reviews (id, document_id, admin_id, action, comment, governance_ref, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)").run(i().randomUUID(),a.documentId,a.adminId,a.action,b,c,new Date().toISOString()),e.prepare("UPDATE documents SET status = ?, updated_at = ? WHERE id = ?").run(d,new Date().toISOString(),a.documentId),e.exec("COMMIT")}catch(a){throw e.exec("ROLLBACK"),a}}function R(a){return a.length<1?"Kamida bitta fayl biriktiring.":a.length>30?"Bir yuborishda 30 tadan oshiq fayl biriktirilmaydi.":a.some(a=>a.label.trim().length<2)?"Har bir faylga nom yozing.":""}async function S(a){await q();let b=o().prepare("SELECT id, document_id, version, note, created_at FROM submission_rounds WHERE document_id = ? ORDER BY version ASC").all(a),c=o().prepare(`SELECT f.id, f.round_id, f.label, f.original_name, f.mime, f.size, f.created_at
       FROM submission_files f
       JOIN submission_rounds r ON r.id = f.round_id
       WHERE r.document_id = ?
       ORDER BY f.created_at ASC`).all(a);return b.map(a=>({...a,files:c.filter(b=>b.round_id===a.id)}))}async function T(a){return await q(),o().prepare(`SELECT f.id, f.round_id, f.label, f.stored_name, f.original_name, f.mime, f.size, f.created_at, d.owner_id
         FROM submission_files f
         JOIN submission_rounds r ON r.id = f.round_id
         JOIN documents d ON d.id = r.document_id
         WHERE f.id = ?`).get(a)??null}function U(a,b,c,d,e,f){let g=i().randomUUID();a.prepare("INSERT INTO submission_rounds (id, document_id, version, note, created_at) VALUES (?, ?, ?, ?, ?)").run(g,b,c,d,e);let h=a.prepare("INSERT INTO submission_files (id, round_id, label, stored_name, original_name, mime, size, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");for(let a of f)h.run(i().randomUUID(),g,a.label.trim(),a.storedName,a.originalName,a.mime,a.size,e)}async function V(a){await q();let b=a.title.trim(),c=a.note.trim();if(b.length<3)return{error:"Ariza nomi kamida 3 ta belgidan iborat bo‘lsin."};let d=R(a.files);if(d)return{error:d};let e=i().randomUUID(),f=new Date().toISOString(),g=o();g.exec("BEGIN");try{g.prepare("INSERT INTO documents (id, owner_id, type, title, body, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'SUBMITTED', ?, ?)").run(e,a.ownerId,a.type,b,c,f,f),U(g,e,1,c,f,a.files),g.exec("COMMIT")}catch(a){throw g.exec("ROLLBACK"),a}return{id:e}}async function W(a){await q();let b=a.title.trim(),c=a.note.trim();if(b.length<3)return{error:"Ariza nomi kamida 3 ta belgidan iborat bo‘lsin."};let d=R(a.files);if(d)return{error:d};let e=await M(a.id);if(!e||e.owner_id!==a.ownerId)return{error:"Ariza topilmadi."};if("DRAFT"!==e.status&&"REVISION"!==e.status)return{error:"Bu arizani hozir qayta yuborib bo‘lmaydi."};let f=o(),g=f.prepare("SELECT COALESCE(MAX(version), 0) AS version FROM submission_rounds WHERE document_id = ?").get(a.id),h=new Date().toISOString();f.exec("BEGIN");try{let d=g.version;0===d&&e.body.trim()&&(d=1,U(f,a.id,d,e.body.trim(),e.created_at,[])),d+=1,U(f,a.id,d,c,h,a.files),f.prepare("UPDATE documents SET type = ?, title = ?, body = ?, status = 'SUBMITTED', updated_at = ? WHERE id = ? AND owner_id = ?").run(a.type,b,c,h,a.id,a.ownerId),f.exec("COMMIT")}catch(a){throw f.exec("ROLLBACK"),a}return{id:a.id}}}};